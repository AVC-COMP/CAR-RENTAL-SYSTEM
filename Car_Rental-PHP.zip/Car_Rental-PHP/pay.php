<?php 
        $curl = curl_init();
    
        $customer_email = $_GET["email"];
        $amount_pay = 55000;
        $currency = "NGN";
        $txref = "rave" . uniqid();
        $PBFPubKey = "FLWPUBK_TEST-6082ffff61111c378374829dd64357e0-X"; 
        $redirect_url = "http://localhost/Car_Rental-PHP/login";
    
        curl_setopt_array($curl, array(
        CURLOPT_URL => "https://api.ravepay.co/flwv3-pug/getpaidx/api/v2/hosted/pay",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => json_encode([
            'amount'=>$amount_pay,
            'customer_email'=>$customer_email,
            'currency'=>$currency,
            'txref'=>$txref,
            'PBFPubKey'=>$PBFPubKey,
            'redirect_url'=>$redirect_url,
        ]),
        CURLOPT_HTTPHEADER => [
            "content-type: application/json",
            "cache-control: no-cache"
        ],
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    if($err){
        die('Curl returned error: ' . $err);
    }

    $transaction = json_decode($response);

    if(!$transaction->data && !$transaction->data->link){
        print_r('API returned error: ' . $transaction->message);
    }

    header('Location: ' . $transaction->data->link);
?>